# BDI
This is a composer-installable PHAR distribution of [dbrekelmans/browser-driver-installer](https://github.com/dbrekelmans/browser-driver-installer).

Releases are automated with github actions.

## Contributing
If you want to contribute to the code of the actual tool, head over to [dbrekelmans/browser-driver-installer](https://github.com/dbrekelmans/browser-driver-installer).
