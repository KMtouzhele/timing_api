---
title: lastChild
---

```php
lastChild () : object
```

Returns the last child of the root element.