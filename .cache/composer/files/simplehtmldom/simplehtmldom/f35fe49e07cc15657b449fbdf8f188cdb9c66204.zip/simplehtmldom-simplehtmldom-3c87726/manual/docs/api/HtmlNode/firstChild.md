---
title: firstChild
---

```php
firstChild ( ) : mixed
```

Returns the first child node of the current node or null if the current nod has no child nodes.