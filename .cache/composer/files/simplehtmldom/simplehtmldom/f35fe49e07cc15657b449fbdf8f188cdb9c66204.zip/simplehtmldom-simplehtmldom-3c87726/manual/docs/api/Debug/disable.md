---
title: disable()
---

```php
Debug::disable ()
```

Globally disables debug messages.