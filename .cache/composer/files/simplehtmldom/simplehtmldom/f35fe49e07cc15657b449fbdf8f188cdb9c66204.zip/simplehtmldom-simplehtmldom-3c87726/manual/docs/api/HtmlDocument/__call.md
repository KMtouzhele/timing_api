---
title: __call
---

```php
__call ($function, $arguments)
```

Serves as a wrapper for deprecated methods. See [magic methods](https://www.php.net/manual/en/language.oop5.overloading.php#object.call) for more information.